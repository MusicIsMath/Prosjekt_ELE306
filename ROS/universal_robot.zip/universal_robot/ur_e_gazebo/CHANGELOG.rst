^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ur_e_gazebo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.2.7 (2019-11-23)
------------------

1.2.6 (2019-11-19)
------------------
* Migrated all package.xml files to format=2 (`#439 <https://github.com/ros-industrial/universal_robot/issues/439>`_)
* Load the JointGroupPositionController so jog commands can be sent (`#422 <https://github.com/ros-industrial/universal_robot/issues/422>`_)
* Contributors: AndyZe, Felix Mauch

1.2.5 (2019-04-05)
------------------
* First release (of this package)
* Update maintainer listing: add Miguel (`#410 <https://github.com/ros-industrial/universal_robot/issues/410>`_)
* UR-E Series (`#380 <https://github.com/ros-industrial/universal_robot/issues/380>`_)
* Contributors: Dave Niewinski, gavanderhoorn
