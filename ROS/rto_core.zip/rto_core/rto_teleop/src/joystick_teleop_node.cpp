/*
 * joystick_teleop_node.cpp
 *
 *  Created on: 16.12.2011
 *      Author: indorewala@servicerobotics.eu
 */

#include "JoystickTeleop.h"

#include <ros/ros.h>

int main( int argc, char** argv )
{
	ros::init( argc, argv, "joystick_teleop_node" );
	JoystickTeleop rt_;
	rt_.spin();

	return 0;
}

